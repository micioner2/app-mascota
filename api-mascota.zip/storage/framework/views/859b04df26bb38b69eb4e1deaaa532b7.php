<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Obtener Token de Google</title>
    <script src="https://accounts.google.com/gsi/client" async defer></script>
</head>

<body>

    <h2>Autenticación con Google</h2>

    <div id="g_id_onload" data-client_id="<?php echo e($googleClientId); ?>" data-context="signin" data-ux_mode="redirect"
        data-login_uri="<?php echo e(config('services.google.redirect')); ?>" data-callback="handleCredentialResponse">
    </div>

    <div class="g_id_signin" data-type="standard"></div>

    <h3>Token obtenido:</h3>
    <pre id="token-display">Ninguno</pre>

    <button onclick="testAuthentication()">Enviar Token</button>

    <h3>Respuesta del Servidor:</h3>
    <pre id="api-response">Esperando respuesta...</pre>

    <script>
        const googleClientId = <?php echo json_encode($googleClientId, 15, 512) ?>;
        const googleRedirectUri = "<?php echo e(config('services.google.redirect')); ?>";

        console.log("Google Client ID:", googleClientId);
        console.log("Redirect URI:", googleRedirectUri);

        function handleCredentialResponse(response) {
            console.log("Token recibido:", response.credential);
            document.getElementById('token-display').textContent = response.credential;
        }

        function testAuthentication() {
            const token = document.getElementById('token-display').textContent;
            const responseElement = document.getElementById('api-response');

            if (token === "Ninguno") {
                alert("No hay token disponible. Inicia sesión con Google primero.");
                return;
            }

            responseElement.textContent = "Enviando solicitud...";

            fetch("<?php echo e(route('google.token')); ?>", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        id_token: token
                    })
                })
                .then(response => response.json())
                .then(data => {
                    responseElement.textContent = JSON.stringify(data, null, 2);
                })
                .catch(error => {
                    responseElement.textContent = "Error: " + error.message;
                    console.error('Error:', error);
                });
        }
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\app-mascota\api-mascota\resources\views/auth/google-obtener-token.blade.php ENDPATH**/ ?>